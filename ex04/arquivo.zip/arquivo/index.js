var extract = require('extract-zip')
extract("./arquivo.zip", {dir: "C:/temp/subpasta"}, function (err) {
 
})